const canvas = document.getElementById('stars');
const ctx = canvas.getContext('2d');

let width, height, stars;

function init() {
    width = window.innerWidth;
    height = window.innerHeight;
    canvas.width = width;
    canvas.height = height;

    stars = [];
    for (let i = 0; i < 200; i++) {
        stars.push({
            x: Math.random() * width,
            y: Math.random() * height,
            size: Math.random() * 2,
            speed: Math.random() * 0.5 + 0.1
        });
    }
}

function animate() {
    ctx.fillStyle = '#000';
    ctx.fillRect(0, 0, width, height);

    ctx.fillStyle = '#fff';
    stars.forEach(star => {
        ctx.beginPath();
        ctx.arc(star.x, star.y, star.size, 0, Math.PI * 2);
        ctx.fill();

        star.y += star.speed;
        if (star.y > height) {
            star.y = 0;
            star.x = Math.random() * width;
        }
    });

    requestAnimationFrame(animate);
}

window.addEventListener('resize', init);

// File Upload Logic
const fileUpload = document.getElementById('file-upload');
const fileList = document.getElementById('file-list');

fileUpload.addEventListener('change', (e) => {
    const files = e.target.files;
    fileList.innerHTML = '';
    for (let i = 0; i < files.length; i++) {
        const item = document.createElement('div');
        item.textContent = files[i].name;
        fileList.appendChild(item);
    }
    // In a real app, you'd handle the file data here
    console.log(`${files.length} files selected`);
});

init();
animate();
